@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo.
echo ==============================================
echo   AI 简历拷打机 - 本地隐私版
echo   简历不会上传到作者服务器
echo ==============================================
echo.
where py >nul 2>nul
if errorlevel 1 (
  echo 未找到 Python。请先安装 Python 3.10 或更高版本：
  echo https://www.python.org/downloads/
  pause
  exit /b 1
)
if not exist .venv (
  echo 正在创建本地环境……
  py -3 -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m streamlit run app.py --browser.gatherUsageStats false --server.address 127.0.0.1
pause
